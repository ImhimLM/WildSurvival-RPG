plains = [
    'rabbit',
    'cow',
    'sheep',
    'pig',
    'chicken'
]

forest = [
    'deer',
    'rabbit',
    'hare',
    'bird'
]

mountains = [
    'goat',
    'deer',
    'sheep',
    'pig'
]

desert = [
    'deer',
    'hare'
]

snowyplains = [
    'goat',
    'hare'
]

beach = [
    'lobster',
    'small fish'
]