plains = [
    ['buffalo', 20],
    ['cattle', 15],
    ['wolf', 10]
]

forest = [
    ['wolf', 10],
    ['bear', 20]
]

mountains = [
    ['aggressive goat', 10],
    ['cattle', 15]
]

desert = [
    ['snake', 20],
    ['scorpion', 10]
]

snowyplains = [
    ['polar bear', 30]
]

beach = [
    ['crab', 5]
]