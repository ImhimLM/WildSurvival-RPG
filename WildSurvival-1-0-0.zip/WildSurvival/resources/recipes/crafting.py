items = [
    'stick',
    'stone sword',
    'camp fire',
    'wool',
    'sail',
    'paddle',
    'boat'
]

recipes = [
    ['stick', [['wood', 2]]],
    ['stone sword', [['stick', 1], ['rock', 4]]],
    ['camp fire', [['wood', 15]]],
    ['wool', [['string', 2]]],
    ['sail', [['wool', 10]]],
    ['paddle', [['stick', 2], ['wood', 1]]],
    ['boat', [['wood', 100], ['sail', 1], ['paddle', 2]]]
]

recipeResults = [
    ['stick', 4],
    ['stone sword', 1],
    ['camp fire', 1],
    ['wool', 1],
    ['sail', 1],
    ['paddle', 1],
    ['boat', 1]
]