cookedItems = [
    'water bottle',
    'cooked rabbit',
    'cooked hare',
    'cooked cow',
    'cooked sheep',
    'cooked pig',
    'cooked chicken',
    'cooked deer',
    'cooked bird',
    'cooked goat',
    'cooked mushroom',
    'cooked lobster',
    'cooked small fish'
]

rawItems = [
    'dirty water bottle',
    'rabbit',
    'hare',
    'cow',
    'sheep',
    'pig',
    'chicken',
    'deer',
    'bird',
    'goat',
    'mushroom',
    'lobster',
    'small fish'
]

recipes = [
    ['water bottle', 'dirty water bottle'],
    ['cooked rabbit', 'rabbit'],
    ['cooked hare', 'hare'],
    ['cooked cow', 'cow'],
    ['cooked sheep', 'sheep'],
    ['cooked pig', 'pig'],
    ['cooked chicken', 'chicken'],
    ['cooked deer', 'deer'],
    ['cooked bird', 'bird'],
    ['cooked goat', 'goat'],
    ['cooked mushroom', 'mushroom'],
    ['cooked lobster', 'lobster'],
    ['cooked small fish', 'small fish']
]