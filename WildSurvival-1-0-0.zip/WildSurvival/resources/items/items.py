weapons = [
    'stone sword'
]

cookItems = [
    'camp fire'
]

edible = [
    ['cooked rabbit', 10],
    ['cooked hare', 10],
    ['cooked cow', 30],
    ['cooked sheep', 25],
    ['cooked pig', 20],
    ['cooked chicken', 15],
    ['cooked deer', 30],
    ['cooked bird', 10],
    ['cooked goat', 20],
    ['cooked mushroom', 5],
    ['cooked lobster', 15],
    ['cooked small fish', 5]
]

drinkable = [
    ['water bottle', 50]
]

edibleSingle = [
    'cooked rabbit',
    'cooked hare',
    'cooked cow',
    'cooked sheep',
    'cooked pig',
    'cooked chicken',
    'cooked deer',
    'cooked bird',
    'cooked goat',
    'cooked mushroom',
    'cooked lobster',
    'cooked small fish'
]

drinkableSingle = [
    'water bottle'
]

waterContainers = [
    'empty bottle'
]

waterContainersFull = [
    'dirty water bottle'
]