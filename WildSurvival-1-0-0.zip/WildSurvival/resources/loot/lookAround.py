plains = ['stick', 'mushroom', 'rock', 'string']
forest = ['stick', 'mushroom', 'acorn', 'string']
mountains = ['stick', 'rock']
desert = ['stick', 'bone', 'rock', 'string']
snowyplains = ['stick', 'rock']
beach = ['wood', 'stick', 'rock', 'string']

class Max:
    plains = [4, 6, 3, 5]
    forest = [6, 10, 2, 7]
    mountains = [2, 6]
    desert = [4, 3, 2, 3]
    snowyplains = [3, 3]
    beach = [2, 5, 4, 2]