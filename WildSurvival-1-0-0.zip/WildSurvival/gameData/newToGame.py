newToGame = True
