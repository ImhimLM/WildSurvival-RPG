class saveFile:
      gameName = 'NO_SAVE_NAME'

      class Player:
           health = 0
           hunger = 0
           thirst = 0

           area = 'NO_AREA'

           score = 0

           inventory = []
           inventoryAmount = []
