#### DATA ####

# Modules
import os, random, shutil, sys, signal
from colorama import Style, Fore

# Import Files
import saveFile
import gameData.createdGame as createdGame
import gameData.newToGame as newToGame

import resources.recipes.crafting
import resources.recipes.cooking
import resources.items.items
import resources.animals.animals
import resources.animals.aggressiveAnimals
import resources.loot.lookAround

# Variables and Lists
gameDirectory = os.getcwd()

selection = ''

# Functions
def clear():
    os.system('clear')

def option(name, number):
    return str(Fore.RESET + Style.RESET_ALL + str(name) + Fore.RESET + ' [' + Fore.CYAN + str(number) + Fore.RESET + ']')

def setup():
    clear()
    print('Loading...')
    clearCache()
    removeUnwantedFiles()
    print('')
    print('Loading complete!')

def clearCache():
    print('')

    try:
        cacheDirectory = gameDirectory + '/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

    try:
        cacheDirectory = gameDirectory + '/exports/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/exports/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

    try:
        cacheDirectory = gameDirectory + '/gameData/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/gameData/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

    try:
        cacheDirectory = gameDirectory + '/resources/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/resources/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

    try:
        cacheDirectory = gameDirectory + '/resources/animals/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/resources/animals/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

    try:
        cacheDirectory = gameDirectory + '/resources/items/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/resources/items/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

    try:
        cacheDirectory = gameDirectory + '/resources/loot/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/resources/loot/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

    try:
        cacheDirectory = gameDirectory + '/resources/recipes/__pycache__'
        shutil.rmtree(cacheDirectory)
        print('Removed ' + cacheDirectory)
    except FileNotFoundError:
        cacheDirectory = gameDirectory + '/resources/recipes/__pycache__'
        print('Could not remove ' + cacheDirectory + ', folder not found')

def removeUnwantedFiles():
    print('')

    files = os.listdir(gameDirectory)

    requiredFiles = ['saveFile.py', 'main.py', 'get-pip.py', 'MacOS.command', 'command.txt', 'resources', 'gameData', 'exports', '.DS_Store']
    unwantedFile = False

    for i in files:
        if not i in requiredFiles:
            unwantedFile = True
            unwantedDirectory = gameDirectory + '/' + i
            if os.path.isfile(unwantedDirectory) == True:
                os.remove(unwantedDirectory)
                print('Removed unwanted file ' + unwantedDirectory)
            elif os.path.isdir(unwantedDirectory) == True:
                shutil.rmtree(unwantedDirectory)
                print('Removed unwanted folder ' + unwantedDirectory)
            else:
                print('Could not remove ' + unwantedDirectory + ', unknown type')

    if unwantedFile == False:
        print('No unwanted files/folders to clean up')

# Classes
class Player:
    health = 100
    hunger = 100
    thirst = 100

    area = ''

    score = 0

    inventory = ['stone axe', 'empty bottle']
    inventoryAmount = [1, 1]

    class death:
        def general():
            return Fore.RED + Style.BRIGHT + 'You died!' + Fore.RESET + Style.RESET_ALL

        def hunger():
            return Fore.RED + Style.BRIGHT + 'You starved to death!' + Fore.RESET + Style.RESET_ALL

        def thirst():
            return Fore.RED + Style.BRIGHT + 'You died from thirst!' + Fore.RESET + Style.RESET_ALL

    class Modify:
        def health(amount):
            Player.health += amount

            if amount < 0:
                return Fore.RED + str(amount) + ' health!' + Fore.RESET
            else:
                return Fore.GREEN + '+' + str(amount) + ' health!' + Fore.RESET
        
        def hunger(amount):
            Player.hunger += amount

            if amount < 0:
                return Fore.RED + str(amount) + ' hunger!' + Fore.RESET
            else:
                return Fore.GREEN + '+' + str(amount) + ' hunger!' + Fore.RESET

        def thirst(amount):
            Player.thirst += amount

            if amount < 0:
                return Fore.RED + str(amount) + ' thirst!' + Fore.RESET
            else:
                return Fore.GREEN + '+' + str(amount) + ' thirst!' + Fore.RESET

        def score(amount):
            Player.score += amount

            if amount > 0:
                return Fore.LIGHTBLUE_EX + '+' + str(amount) + ' score!' + Fore.RESET
            else:
                return Fore.LIGHTBLUE_EX + str(amount) + ' score!' + Fore.RESET

    def addItem(name, amount):
        if not name in Player.inventory:
            Player.inventory.append(name)
            Player.inventoryAmount.append(amount)
        else:
            itemID = Player.inventory.index(name)
            Player.inventoryAmount[itemID] += amount

    def removeItem(name, amount):
        if name in Player.inventory:
            itemID = Player.inventory.index(name)
            Player.inventoryAmount[itemID] -= amount
            
            if Player.inventoryAmount[itemID] < 1:
                del Player.inventory[itemID]
                del Player.inventoryAmount[itemID]

class Game:
    possibleAreas = ['plains', 'forest', 'mountains', 'desert', 'snowyplains', 'beach']

    def ending(name, description):
        clear()
        print(Style.BRIGHT + name.upper() + Style.RESET_ALL)
        print('')
        print(description)

    class Loot:
        class lookAround:
            plains = resources.loot.lookAround.plains
            forest = resources.loot.lookAround.forest
            mountains = resources.loot.lookAround.mountains
            desert = resources.loot.lookAround.desert
            snowyplains = resources.loot.lookAround.snowyplains
            beach = resources.loot.lookAround.beach

            class Max:
                plains = resources.loot.lookAround.Max.plains
                forest = resources.loot.lookAround.Max.forest
                mountains = resources.loot.lookAround.Max.mountains
                desert = resources.loot.lookAround.Max.desert
                snowyplains = resources.loot.lookAround.Max.snowyplains
                beach = resources.loot.lookAround.Max.beach

    class Items:
        weapons = resources.items.items.weapons

        cookItems = resources.items.items.cookItems

        edible = resources.items.items.edible

        drinkable = resources.items.items.drinkable

        edibleSingle = resources.items.items.edibleSingle

        drinkableSingle = resources.items.items.drinkableSingle

        waterContainers = resources.items.items.waterContainers

        waterContainersFull = resources.items.items.waterContainersFull

    class Animals:
        plains = resources.animals.animals.plains

        forest = resources.animals.animals.forest

        mountains = resources.animals.animals.mountains

        desert = resources.animals.animals.desert

        snowyplains = resources.animals.animals.snowyplains

        beach = resources.animals.animals.beach

    class aggressiveAnimals:
        plains = resources.animals.aggressiveAnimals.plains

        forest = resources.animals.aggressiveAnimals.forest

        mountains = resources.animals.aggressiveAnimals.mountains

        desert = resources.animals.aggressiveAnimals.desert

        snowyplains = resources.animals.aggressiveAnimals.snowyplains

        beach = resources.animals.aggressiveAnimals.beach

    class Recipe:
        items = resources.recipes.crafting.items

        recipes = resources.recipes.crafting.recipes

        recipeResults = resources.recipes.crafting.recipeResults

    class cookingRecipe:
        cookedItems = resources.recipes.cooking.cookedItems

        rawItems = resources.recipes.cooking.rawItems

        recipes = resources.recipes.cooking.recipes

    class Actions:
        def lookAround(lootType):
            loot = getattr(Game.Loot.lookAround, Player.area)
            lootAmount = getattr(Game.Loot.lookAround.Max, Player.area)

            clear()

            if random.randint(1, 2) == 1:
                if random.randint(1, 6) == 1:
                    playerOwnsWeapon = False

                    aggressiveAnimalList = random.choice(getattr(Game.aggressiveAnimals, Player.area))

                    aggressiveAnimal = aggressiveAnimalList[0]
                    animalDamage = aggressiveAnimalList[1]

                    print('Oh no! You stumbled accross ' + Style.BRIGHT + aggressiveAnimal.upper() + Style.RESET_ALL + '!')
                    
                    for i in Game.Items.weapons:
                        if i in Player.inventory:
                            playerOwnsWeapon = True

                    if playerOwnsWeapon == True:
                        print('You attempted to fight the animal with a weapon')
                        if random.randint(1, 2) == 1:
                            print(Fore.GREEN + 'You defeated the animal!' + Fore.RESET)
                            input('Enter to continue')
                            gameMenu()
                        else:
                            print(Fore.RED + 'You couldn\'t defeat the animal and it almost defeated you!' + Fore.RESET)
                            print(Player.Modify.health(animalDamage * -1))
                            input('Enter to continue')
                            gameMenu()
                    else:
                        print('You attempted to run from the animal')
                        if random.randint(1, 2) == 1:
                            print(Fore.GREEN + 'You successfully ran from animal! The running was very tiring...' + Fore.RESET)
                            print(Player.Modify.hunger(-20))
                            print(Player.Modify.thirst(-10))
                            input('Enter to continue')
                            gameMenu()
                        else:
                            print(Fore.RED + 'The animal caught up to you and did massive damage!' + Fore.RESET)
                            print(Player.Modify.health(animalDamage * -2))
                            input('Enter to continue')
                            gameMenu()
                else:
                    item = random.choice(loot)
                    itemID = loot.index(item)
                    itemAmount = random.randint(1, lootAmount[itemID])
                    print('You found x' + str(itemAmount) + ' ' + Style.BRIGHT + item.upper() + Style.RESET_ALL + '!')
                    Player.addItem(item, itemAmount)
                    print(Player.Modify.hunger(-3))
                    print(Player.Modify.thirst(-2))
                    print(Player.Modify.score(5))
                    input('Enter to continue')
                    gameMenu()
            else:
                print(Fore.RED + 'You found nothing!' + Fore.RESET)
                print(Player.Modify.hunger(-5))
                print(Player.Modify.thirst(-3))
                input('Enter to continue')
                gameMenu()

        def exploreNew():
            clear()
            if random.randint(1, 2) == 1:
                oldArea = Player.area
                newArea = random.choice(Game.possibleAreas)
                Player.area = newArea

                if not oldArea == newArea:
                    print('You found ' + Style.BRIGHT + newArea.upper() + Style.RESET_ALL + '!')
                    print(Player.Modify.hunger(-4))
                    print(Player.Modify.thirst(-2))
                    print(Player.Modify.score(7))
                    input('Enter to continue')
                    gameMenu()
                else:
                    print(Fore.RED + 'You found nothing!' + Fore.RESET)
                    print(Player.Modify.hunger(-4))
                    print(Player.Modify.thirst(-2))
                    input('Enter to continue')
                    gameMenu()
            else:
                print(Fore.RED + 'You found nothing!' + Fore.RESET)
                print(Player.Modify.hunger(-4))
                print(Player.Modify.thirst(-2))
                input('Enter to continue')
                gameMenu()

        def viewInventory():
            clear()
            if len(Player.inventory) > 0:
                print('Your inventory:')
                for i in Player.inventory:
                    itemID = Player.inventory.index(i)
                    print(str(itemID + 1) + '. x' + str(Player.inventoryAmount[itemID]) + ' ' + i.capitalize())
                print('')
                input('Enter to continue')
                gameMenu()
            else:
                print(Fore.RED + 'You do not have anything in your inventory!' + Fore.RESET)
                input('Enter to continue')
                gameMenu()

        def chopWood():
            clear()
            if not Player.area == 'desert':
                itemAmount = random.randint(3, 8)
                print('You got x' + str(itemAmount) + Style.BRIGHT + ' WOOD' + Style.RESET_ALL + '!')
                Player.addItem('wood', itemAmount)
                print(Player.Modify.hunger(-5))
                print(Player.Modify.thirst(-2))
                print(Player.Modify.score(2))
                input('Enter to continue')
                gameMenu()
            else:
                print(Fore.RED + 'You are in ' + Style.BRIGHT + Player.area.upper() + Style.RESET_ALL + Fore.RED + ', that area does not have any trees to chop!' + Fore.RESET)
                input('Enter to continue')
                gameMenu()

        def craft():
            clear()
            print(Style.BRIGHT + 'Crafting:' + Style.RESET_ALL)
            for i in Game.Recipe.recipes:
                itemID = Game.Recipe.recipes.index(i)
                print(Style.RESET_ALL + 'x' + str(Game.Recipe.recipeResults[itemID][1]) + ' ' + Style.BRIGHT + i[0].upper() + Style.RESET_ALL)
            print('')
            print('Write the name of the item you would like to craft (Leave blank to exit)')
            selection = input('> ')

            if selection.lower() in Game.Recipe.items:
                clear()
                itemID = Game.Recipe.items.index(selection.lower())
                itemList = []
                itemAmountList = []
                craftResult = Game.Recipe.recipeResults[itemID][0]
                craftResultList = Game.Recipe.recipeResults[itemID]
                print('Would you like to craft x' + str(Game.Recipe.recipeResults[itemID][1]) + ' ' + Style.BRIGHT + Game.Recipe.items[itemID].upper() + Style.RESET_ALL + '? It will require:')
                for i in Game.Recipe.recipes[itemID][1]:
                    itemList.append(i[0])
                    itemAmountList.append(i[1])
                    print('x' + str(i[1]) + ' ' + i[0].capitalize())
                print('')
                print(option('Yes', 1))
                print(option('No ', 2))
                selection = input('> ')

                if selection == '1':
                    craftableList = Game.Events.detectItems(itemList, itemAmountList)
                    craftable = None
                    for i in range(0, int(selection)):
                        for i in craftableList:
                            if i == False:
                                craftable = False
                            else:
                                craftable = True
                        
                        if craftable == False:
                            print(Fore.RED + 'You do not have enough items for this item' + Fore.RESET)
                            input('Enter to continue')
                            Game.Actions.craft()
                        else:
                            print(Fore.GREEN + 'You crafted ' + Style.BRIGHT + str(craftResult.upper()) + Style.RESET_ALL + Fore.GREEN + '!' + Fore.RESET)
                            for i in itemList:
                                itemID = itemList.index(i)
                                Player.removeItem(i, itemAmountList[itemID])
                            Player.addItem(craftResultList[0], craftResultList[1])
                            print(Player.Modify.score(3))
                            input('Enter to continue')
                            gameSave.saveGame()
                            Game.Actions.craft()
                else:
                    Game.Actions.craft()
            elif selection == '':
                gameMenu()
            else:
                print(Fore.RED + 'Unknown item "' + selection + '"' + Fore.RESET)
                input('Enter to continue')
                Game.Actions.craft()

        def hunt():
            clear()

            playerOwnsWeapon = False

            for i in Game.Items.weapons:
                if i in Player.inventory:
                    playerOwnsWeapon = True
            
            if playerOwnsWeapon == True:
                if random.randint(1, 3) == 1:
                    possibleAnimals = getattr(Game.Animals, Player.area)

                    animalHunted = random.choice(possibleAnimals)

                    Player.addItem(animalHunted, 1)

                    print(Fore.GREEN + 'You found ' + Style.BRIGHT + animalHunted.upper() + Style.RESET_ALL + Fore.GREEN + '!' + Fore.RESET)
                    print(Player.Modify.hunger(-2))
                    print(Player.Modify.thirst(-1))
                    print(Player.Modify.score(7))
                    input('Enter to continue')
                    gameMenu()
                else:
                    print(Fore.RED + 'You didn\'t find any animals!' + Fore.RESET)
                    print(Player.Modify.hunger(-2))
                    print(Player.Modify.thirst(-1))
                    input('Enter to continue')
                    gameMenu()
            else:
                print(Fore.RED + 'You do not have a weapon!' + Fore.RESET)
                input('Enter to continue')
                gameMenu()

        def cook():
            clear()

            playerOwnsRawItems = False

            print(Style.BRIGHT + 'Cooking:' + Style.RESET_ALL)

            for i in Game.cookingRecipe.rawItems:
                if i in Player.inventory:
                    itemID = Player.inventory.index(i)
                    itemAmount = Player.inventoryAmount[itemID]
                    print('x' + str(itemAmount) + ' ' + i.capitalize())
                    playerOwnsRawItems = True

            if playerOwnsRawItems == True:
                print('')
                print('Write the food you would like to cook (Leave blank to exit):')
                selection = input('> ')

                if selection == '':
                    gameMenu()
                else:
                    if selection in Game.cookingRecipe.rawItems:
                        if selection in Player.inventory:
                            itemID = Game.cookingRecipe.rawItems.index(selection)
                            cookedItem = Game.cookingRecipe.recipes[itemID][0]
                            rawItem = Game.cookingRecipe.recipes[itemID][1]
                            Player.removeItem(rawItem, 1)
                            Player.addItem(cookedItem, 1)
                            print(Fore.GREEN + 'You cooked "' + Style.BRIGHT + rawItem.upper() + Style.RESET_ALL + Fore.GREEN + '"!' + Fore.RESET)
                            print(Player.Modify.score(2))
                            input('Enter to continue')
                            Game.Actions.cook()
                        else:
                            print(Fore.RED + 'You do not have that item!' + Fore.RESET)
                            input('Enter to continue')
                            Game.Actions.cook()
                    else:
                        print(Fore.RED + '"' + selection + '" is not a food you can cook!' + Fore.RESET)
                        input('Enter to continue')
                        Game.Actions.cook()
            else:
                clear()
                print(Fore.RED + 'You do not have any raw food items!' + Fore.RESET)
                input('Enter to continue')
                gameMenu()

        def eat():
            clear()

            playerOwnsEdibleItems = False

            print(Style.BRIGHT + 'Eating:' + Style.RESET_ALL)
            print('You have ' + str(Player.hunger) + ' hunger')
            print('')

            for i in Game.Items.edible:
                if i[0] in Player.inventory:
                    itemID = Player.inventory.index(i[0])
                    itemAmount = Player.inventoryAmount[itemID]
                    print('x' + str(itemAmount) + ' ' + i[0].capitalize() + ', +' + str(i[1]) + ' hunger')
                    playerOwnsEdibleItems = True
            
            if playerOwnsEdibleItems == True:
                print('')
                print('Write the food you would like to eat (Leave blank to exit):')
                selection = input('> ')

                if selection == '':
                    gameMenu()
                else:
                    if selection in Game.Items.edibleSingle:
                        if selection in Player.inventory:
                            itemID = Game.Items.edibleSingle.index(selection)
                            foodItem = Game.Items.edibleSingle[itemID]
                            hungerReplenishAmount = Game.Items.edible[itemID][1]
                            Player.removeItem(foodItem, 1)
                            print(Fore.GREEN + 'You ate ' + Style.BRIGHT + foodItem.upper() + Style.RESET_ALL + Fore.GREEN + '!' + Fore.RESET)
                            print(Player.Modify.hunger(int(hungerReplenishAmount)))
                            if Player.health < 110:
                                print(Player.Modify.health(random.randint(5, 15)))
                            input('Enter to continue')
                            Game.Actions.eat()
                        else:
                            print(Fore.RED + 'You do not have that food item!' + Fore.RESET)
                            input('Enter to continue')
                            Game.Actions.eat()
                    else:
                        print(Fore.RED + 'That is not an edible food item!' + Fore.RESET)
                        input('Enter to continue')
                        Game.Actions.eat()
            else:
                clear()
                print(Fore.RED + 'You do not have any food items!' + Fore.RESET)
                input('Enter to continue')
                gameMenu()

        def findWater():
            clear()

            playerOwnsContainer = False
            waterContainer = ''

            for i in Player.inventory:
                if i in Game.Items.waterContainers:
                    playerOwnsContainer = True
                    waterContainer = i

            if playerOwnsContainer == True:
                if random.randint(1, 2) == 1:
                    itemID = Game.Items.waterContainers.index(waterContainer)
                    fullWaterContainer = Game.Items.waterContainersFull[itemID]
                    Player.removeItem(waterContainer, 1)
                    Player.addItem(fullWaterContainer, 1)

                    waterSource = random.choice(['pond', 'lake', 'river'])

                    print(Fore.GREEN + 'You found dirty water from a ' + Style.BRIGHT + waterSource + Style.RESET_ALL + Fore.GREEN + '!' + Fore.RESET)
                    print(Player.Modify.score(2))
                    input('Enter to continue')
                    gameMenu()
                else:
                    print(Fore.RED + 'You didn\'t find any water!' + Fore.RESET)
                    print(Player.Modify.hunger(-3))
                    print(Player.Modify.thirst(-1))
                    input('Enter to continue')
                    gameMenu()
            else:
                print(Fore.RED + 'You do not have an empty bottle!' + Fore.RESET)
                input('Enter to continue')
                gameMenu()

        def drink():
            clear()

            playerOwnsDrinkableItems = False

            print(Style.BRIGHT + 'Drinking:' + Style.RESET_ALL)
            print('You have ' + str(Player.thirst) + ' thirst')
            print('')

            for i in Game.Items.drinkable:
                if i[0] in Player.inventory:
                    print(i[0].capitalize() + ', +' + str(i[1]) + ' thirst')
                    playerOwnsDrinkableItems = True
            
            if playerOwnsDrinkableItems == True:
                print('')
                print('Write the drink you would like to drink (Leave blank to exit):')
                selection = input('> ')

                if selection == '':
                    gameMenu()
                else:
                    if selection in Game.Items.drinkableSingle:
                        if selection in Player.inventory:
                            itemID = Game.Items.drinkableSingle.index(selection)
                            waterContainer = Game.Items.waterContainers[itemID]
                            drinkableItem = Game.Items.drinkableSingle[itemID]
                            thirstReplenishAmount = Game.Items.drinkable[itemID][1]
                            Player.removeItem(drinkableItem, 1)
                            Player.addItem(waterContainer, 1)
                            print(Fore.GREEN + 'You drank ' + Style.BRIGHT + drinkableItem.upper() + Style.RESET_ALL + Fore.GREEN + '!' + Fore.RESET)
                            print(Player.Modify.thirst(int(thirstReplenishAmount)))
                            input('Enter to continue')
                            Game.Actions.drink()
                        else:
                            print(Fore.RED + 'You do not have that drinkable item!' + Fore.RESET)
                            input('Enter to continue')
                            Game.Actions.drink()
                    else:
                        print(Fore.RED + 'That is not a drinkable item!' + Fore.RESET)
                        input('Enter to continue')
                        Game.Actions.drink()
            else:
                clear()
                print(Fore.RED + 'You do not have any drinkable items!' + Fore.RESET)
                input('Enter to continue')
                gameMenu()

    class Events:
        class die:
            def general():
                clear()
                print(Player.death.general())
                print('Score: ' + Style.BRIGHT + str(Player.score) + Style.RESET_ALL)
                print('')
                input('Enter to continue (This will erase your data!)')
                gameSave.clearData()
                os.execl(sys.executable, os.path.abspath(__file__), *sys.argv)

            def hunger():
                clear()
                print(Player.death.hunger())
                print('Score: ' + Style.BRIGHT + str(Player.score) + Style.RESET_ALL)
                print('')
                input('Enter to continue (This will erase your data!)')
                gameSave.clearData()
                os.execl(sys.executable, os.path.abspath(__file__), *sys.argv)

            def thirst():
                clear()
                print(Player.death.thirst())
                print('Score: ' + Style.BRIGHT + str(Player.score) + Style.RESET_ALL)
                print('')
                input('Enter to continue (This will erase your data!)')
                gameSave.clearData()
                os.execl(sys.executable, os.path.abspath(__file__), *sys.argv)

        def detectDeath():
            if Player.health < 1:
                Game.Events.die.general()
            
            if Player.hunger < 1:
                Game.Events.die.hunger()

            if Player.thirst < 1:
                Game.Events.die.thirst()

        def detectItems(items, amounts):
            result = []

            for i in items:
                itemID = items.index(i)
                if i in Player.inventory:
                    itemInventoryID = Player.inventory.index(i)
                    if Player.inventoryAmount[itemInventoryID] > amounts[itemID] - 1:
                        result.append(True)
                    else:
                        result.append(False)
                else:
                    result.append(False)
            
            return result

        def escape():
            clear()

            print('You are leaving the island...')
            input('Enter to continue')

            if random.randint(1, 10) == 1:
                clear()
                print(Fore.RED + 'You couldn\'t escape the island! Now, you are lost... Forever!' + Fore.RESET)
                input('Enter to continue')

                Game.ending('Bad Ending', 'You couldn\'t find your home, and now you are lost!')
                print('')
                print('Your score: ' + Fore.CYAN + str(Player.score) + Fore.RESET)
                input('Enter to continue')
                gameSave.clearData()
                os.execl(sys.executable, os.path.abspath(__file__), *sys.argv)
            else:
                clear()
                print(Fore.GREEN + 'You escaped the island! Now you\'re back home!' + Fore.RESET)
                input('Enter to continue')

                Game.ending('Good Ending', 'You escaped the island back to your home')
                print('')
                print('Your score: ' + Fore.CYAN + str(Player.score) + Fore.RESET)
                input('Enter to continue')
                gameSave.clearData()
                os.execl(sys.executable, os.path.abspath(__file__), *sys.argv)

class gameSave:
    gameName = ''

    def setCreatedGame(value):
        with open('gameData/createdGame.py', 'r+') as f:
            f.truncate(0)

        with open('gameData/createdGame.py', 'a') as f:
            f.write('createdGame = ' + str(value))

    def setNewToGame(value):
        with open('gameData/newToGame.py', 'r+') as f:
            f.truncate(0)

        with open('gameData/newToGame.py', 'a') as f:
            f.write('newToGame = ' + str(value))

    def clearData():
        with open('saveFile.py', 'r+') as f:
            f.truncate(0)

        with open('saveFile.py', 'r+') as f:
            f.write('class saveFile:\n')
            f.write('      gameName = \'NO_SAVE_NAME\'\n')
            f.write('\n')
            f.write('      class Player:\n')
            f.write('           health = 0\n')
            f.write('           hunger = 0\n')
            f.write('           thirst = 0\n')
            f.write('\n')
            f.write('           area = \'NO_AREA\'\n')
            f.write('\n')
            f.write('           score = ' + str(Player.score) + '\n')
            f.write('\n')
            f.write('           inventory = []\n')
            f.write('           inventoryAmount = []\n')

        gameSave.setCreatedGame('False')

    def saveGame():
        with open('saveFile.py', 'r+') as f:
            f.truncate(0)

        with open('saveFile.py', 'a') as f:
            f.write('class saveFile:\n')
            f.write('      gameName = \'' + str(gameSave.gameName) + '\'\n')
            f.write('\n')
            f.write('      class Player:\n')
            f.write('           health = ' + str(Player.health) + '\n')
            f.write('           hunger = ' + str(Player.hunger) + '\n')
            f.write('           thirst = ' + str(Player.thirst) + '\n')
            f.write('\n')
            f.write('           area = \'' + str(Player.area) + '\'\n')
            f.write('\n')
            f.write('           score = ' + str(Player.score) + '\n')
            f.write('\n')
            f.write('           inventory = ' + str(Player.inventory) + '\n')
            f.write('           inventoryAmount = ' + str(Player.inventoryAmount) + '\n')

    def loadSave():
        try:
            gameSave.gameName = saveFile.saveFile.gameName

            Player.health = saveFile.saveFile.Player.health
            Player.hunger = saveFile.saveFile.Player.hunger
            Player.thirst = saveFile.saveFile.Player.thirst
            Player.area = saveFile.saveFile.Player.area
            Player.score = saveFile.saveFile.Player.score
            Player.inventory = saveFile.saveFile.Player.inventory
            Player.inventoryAmount = saveFile.saveFile.Player.inventoryAmount
        except AttributeError:
            clear()
            print(Fore.RED + 'The save file is corrupted. Please create a new save' + Fore.RESET)
            input('Enter to continue')
            mainMenu()

        gameMenu()

    def renameSave():
        clear()
        print(Style.BRIGHT + 'Rename "' + saveFile.saveFile.gameName + '" (Leave blank for "New Save"):' + Style.RESET_ALL)
        print(Style.BRIGHT + 'Note: ' + Style.RESET_ALL + 'A game refresh is required to update the game name visually!')
        print(Style.BRIGHT + 'Note 2: ' + Style.RESET_ALL + 'Do not resume your game after renaming, as it will reset the new name to the old name!')
        gameSave.gameName = input('> ')

        if gameSave.gameName == '':
            gameSave.gameName = 'New Save'
            gameSave.saveGame()
            gameSave.modifySave()
        elif "'" in gameSave.gameName:
            print(Fore.RED + 'You cannot have a " \' " in the save name!' + Fore.RESET)
            input('Enter to continue')
            gameSave.renameSave()
        else:
            gameSave.saveGame()
            gameSave.modifySave()

    def exportGame():
        clear()

        saveCount = 0
        directory = 'exports'

        for i in os.listdir(directory):
            if os.path.isfile(os.path.join(directory, i)):
                saveCount += 1

        fileName = 'exportedSave' + str(saveCount) + '.py'
        oldFileName = 'exportedSave' + str(saveCount) + '.py'

        filePath = gameDirectory + '/exports'

        createdFile = open(str('exports/' + fileName), 'x')

        with open('saveFile.py', 'r') as f, open(str('exports/' + fileName), 'a') as f2:
            for i in f:
                f2.write(i)

        print(Fore.GREEN + 'Successfully exported ' + Style.BRIGHT + saveFile.saveFile.gameName + Style.RESET_ALL + Fore.GREEN + ' as ' + Style.BRIGHT + fileName + Style.RESET_ALL + Fore.GREEN + '!' + Fore.RESET)
        print('The file can be found in the following path: ' + Style.BRIGHT + filePath + Style.RESET_ALL)
        print('Would you like to change the file name?')
        print(option('Yes', 1))
        print(option('No ', 2))
        selection = input('> ')

        if selection == '1':
            print('')
            print('Please enter a new file name for ' + Style.BRIGHT + fileName + Style.RESET_ALL)
            selection = input('> ')

            if '.' in selection or ' ' in selection:
                print(Fore.RED + 'You cannot have " " or "." in the file name!' + Fore.RESET)
                input('Enter to continue')
                gameSave.modifySave()
            else:
                if selection == '':
                    print(Fore.RED + 'The file name needs to have at least one letter!' + Fore.RESET)
                    input('Enter to continue')
                    gameSave.modifySave()
                else:
                    fileName = selection + '.py'
                    os.rename(str('exports/' + oldFileName), str('exports/' + fileName))
                    print('Renamed ' + Style.BRIGHT + oldFileName + Style.RESET_ALL + ' to ' + Style.BRIGHT + fileName + Style.RESET_ALL + '!')
                    input('Enter to continue')
                    gameSave.modifySave()
        else:
            print('Okay, the file name will stay as it is!')
            input('Enter to continue')
            gameSave.modifySave()

    def importGame():
        clear()

        directory = 'exports'
        files = []

        print('Here\'s a list of exports in the "exports" folder:')
        print(Style.BRIGHT + 'Note: ' + Style.RESET_ALL + 'These export files come from the "exports" folder, so do not expect every save file to be listed!')

        for i in os.listdir(directory):
            if os.path.isfile(os.path.join(directory, i)):
                print(Fore.CYAN + i + Fore.RESET)
                files.append(i)

        if files == []:
            clear()

            print(Fore.RED + 'You do not have any exported games to import!' + Fore.RESET)
            input('Enter to continue')
            gameSave.modifySave()
        else:
            print('')
            print('Enter the name of the file you would like to load (Leave blank to exit):')
            selection = input('> ')

            if selection == '':
                gameSave.modifySave()
            else:
                if selection in files:
                    clear()

                    print('Are you sure you want to import ' + Style.BRIGHT + selection + Style.RESET_ALL + ' as your save file? It will clear all of your current data!')
                    print(option('Yes', 1))
                    print(option('No ', 2))
                    selection = input('> ')

                    if selection == '1':
                        print('Copying file text to save file...')

                        with open('saveFile.py', 'r+') as f:
                            f.truncate(0)

                        with open(str('exports/' + selection), 'r') as f, open('saveFile.py', 'a') as f2:
                            for i in f:
                                f2.write(i)

                        print(Fore.GREEN + 'Successfully imported!' + Fore.RESET)
                        input('Enter to continue')
                        gameSave.modifySave()
                    else:
                        gameSave.importGame()
                else:
                    print(Fore.RED + 'That file does not exist!' + Fore.RESET)
                    input('Enter to continue')
                    gameSave.importGame()

    def modifySave():
        clear()

        print(Style.BRIGHT + 'Modify Save "' + saveFile.saveFile.gameName + '":' + Style.RESET_ALL)
        print(option('Rename·····', 1))
        print(option('Delete·····', 2))
        print(option('Export·····', 3))
        print(option('Import·····', 4))
        print(option('Exit·······', 5))
        selection = input('> ')

        if selection == '1':
            gameSave.renameSave()
        elif selection == '2':
            clear()
            print('Are you sure you want to delete "' + saveFile.saveFile.gameName + '"? It will be lost forever!')
            print(option('Yes', 1))
            print(option('No ', 2))
            selection = input('> ')

            if selection == '1':
                gameSave.clearData()
                os.execl(sys.executable, os.path.abspath(__file__), *sys.argv)
            else:
                gameSave.modifySave()
        elif selection == '3':
            gameSave.exportGame()
        elif selection == '4':
            gameSave.importGame()
        else:
            mainMenu()


#### GAME ####

def startGame():
    clear()

    print('Enter a name for this new save: (Leave blank for "New Save")')
    gameSave.gameName = input('> ')

    if gameSave.gameName == '':
        gameSave.gameName = 'New Save'

    if "'" in gameSave.gameName:
        print(Fore.RED + 'You cannot have a " \' " in the save name!' + Fore.RESET)
        input('Enter to continue')
        startGame()

    Player.area = random.choice(Game.possibleAreas)
    Player.health = 100
    Player.hunger = 100
    Player.thirst = 100
    Player.inventory = ['stone axe', 'empty bottle']
    Player.inventoryAmount = [1, 1]
    gameSave.setCreatedGame('True')
    gameSave.saveGame()
    gameMenu()

def gameMenu():
    clear()
    print('Saving...')
    gameSave.saveGame()

    Game.Events.detectDeath()

    playerOwnsCookingItem = False

    for i in Player.inventory:
        if i in Game.Items.cookItems:
            playerOwnsCookingItem = True

    clear()
    print(Fore.RESET + Style.RESET_ALL + 'You are in ' + Style.BRIGHT + Player.area.upper())
    print(Style.BRIGHT + 'Possible actions:' + Style.RESET_ALL)
    print(option('Look around·····', 1))
    print(option('Explore new area', 2))
    print(option('View inventory··', 3))
    print(option('Chop wood·······', 4))
    print(option('Craft···········', 5))
    print(option('Hunt············', 6))
    print(option('Cook············', 7))
    print(option('Eat·············', 8))
    print(option('Find water······', 9))
    print(option('Drink···········', 10))
    print('You can use "/menu" to return to the main menu')
    if 'boat' in Player.inventory and Player.area == 'beach':
        print(option(Fore.GREEN + 'Escape' + Fore.RESET + '··········', 11))
    print('')
    print(Style.BRIGHT + 'Status:' + Style.RESET_ALL)
    print(Style.BRIGHT + 'HEALTH: ' + Style.RESET_ALL + Fore.LIGHTCYAN_EX + str(Player.health) + Fore.RESET)
    print(Style.BRIGHT + 'HUNGER: ' + Style.RESET_ALL + Fore.LIGHTCYAN_EX + str(Player.hunger) + Fore.RESET)
    print(Style.BRIGHT + 'THIRST: ' + Style.RESET_ALL + Fore.LIGHTCYAN_EX + str(Player.thirst) + Fore.RESET)
    print('')
    print('Select an action from above:')
    selection = input('> ')

    if selection == '1':
        Game.Actions.lookAround(Player.area)
    elif selection == '2':
        Game.Actions.exploreNew()
    elif selection == '3':
        Game.Actions.viewInventory()
    elif selection == '4':
        Game.Actions.chopWood()
    elif selection == '5':
        Game.Actions.craft()
    elif selection == '6':
        Game.Actions.hunt()
    elif selection == '7':
        if playerOwnsCookingItem == True:
            Game.Actions.cook()
        else:
            print(Fore.RED + 'You do not have a cooking item!' + Fore.RESET)
            input('Enter to continue')
            gameMenu()
    elif selection == '8':
        Game.Actions.eat()
    elif selection == '9':
        Game.Actions.findWater()
    elif selection == '10':
        Game.Actions.drink()
    elif selection == '11':
        if 'boat' in Player.inventory and Player.area == 'beach':
            Game.Events.escape()
        else:
            print(Fore.RED + 'Unknown action!' + Fore.RESET)
            input('Enter to continue')
            gameMenu()
    elif selection == '/menu':
        clear()
        print('Are you sure you want to return to the main menu?')
        print(option('Yes', 1))
        print(option('No ', 2))
        selection = input('> ')

        if selection == '1':
            os.execl(sys.executable, os.path.abspath(__file__), *sys.argv)
        else:
            gameMenu()
    else:
        print(Fore.RED + 'Unknown action!' + Fore.RESET)
        input('Enter to continue')
        gameMenu()

def mainMenu():
    clear() 

    spaces = ''

    if createdGame.createdGame == True:
        spaces = '··'
        for i in saveFile.saveFile.gameName:
            spaces = spaces + '·'

    print(Style.BRIGHT + 'Wild Survival RPG' + Style.RESET_ALL)
    print(option(str('New Game·····' + spaces), 1))
    if createdGame.createdGame == True:
        print(option(str(Fore.RESET + 'Continue Game, ' + str(saveFile.saveFile.gameName)), 2))
    else:
        print(option(str(Fore.LIGHTBLACK_EX + 'Continue Game' + Fore.RESET), 2))
    if createdGame.createdGame == True:
        print(option(str('Modify Save··' + spaces), 3))
    else:
        print(option(str(Fore.LIGHTBLACK_EX + 'Modify Save  ' + Fore.RESET), 3))
    print(option(str('Quit Game····' + spaces), 4))
    selection = input('> ')

    if selection == '1':
        if createdGame.createdGame == True:
            clear()
            print('Are you sure you want to do this? It will erase ' + Style.BRIGHT + 'all' + Style.RESET_ALL + ' previous data!')
            print(option('Yes', 1))
            print(option('No ', 2))
            selection = input('> ')
            if selection == '1':
                clear()
                print('Would you like to export your current save?')
                print(option('Yes', 1))
                print(option('No ', 2))
                selection = input('> ')

                if selection == '1':
                            saveCount = 0
                            directory = 'exports'

                            for i in os.listdir(directory):
                                if os.path.isfile(os.path.join(directory, i)):
                                    saveCount += 1

                            fileName = 'exportedSave' + str(saveCount) + '.py'

                            createdFile = open(str('exports/' + fileName), 'x')

                            with open('saveFile.py', 'r') as f, open(str('exports/' + fileName), 'a') as f2:
                                for i in f:
                                    f2.write(i)

                            print('Exported the save file as ' + Style.BRIGHT + fileName + Style.RESET_ALL + '!')
                            input('Enter to continue')
                            startGame()
                else:
                    startGame()
        else:
            startGame()
    elif selection == '2':
        if createdGame.createdGame == True:
            gameSave.loadSave()
        else:
            clear()
            print(Fore.RED + 'You do not have a game to load!' + Fore.RESET)
            input('Enter to continue')
            mainMenu()
    elif selection == '3':
        if createdGame.createdGame == True:
            gameSave.modifySave()
        else:
            clear()
            print(Fore.RED + 'You do not have a game to modify!' + Fore.RESET)
            input('Enter to continue')
            mainMenu()
    else:
        os.kill(os.getppid(), signal.SIGHUP)

if newToGame.newToGame == True:
    clear()
    print('Welcome to ' + Style.BRIGHT + 'Wild Survival' + Style.RESET_ALL + '! A console-based RPG game by ImhimLM!')
    input('Enter to continue')

    clear()
    print('This is a console-based survival game where the goal is to survive through the endless adventure!')
    input('Enter to continue')

    clear()
    print('You will face hunger, thirst, and very mean animals!')
    input('Enter to continue')

    clear()
    print('You will need to hunt down animals, and look around for water.')
    input('Enter to continue')

    clear()
    print('You need to escape the land you are on and find your home using a boat!')
    input('Enter to continue')

    gameSave.setNewToGame(False)

clear()
setup()
mainMenu()